(function ($) {
    $.mobiscroll.i18n.hu = $.extend($.mobiscroll.i18n.hu, {
        setText: 'OK',
        cancelText: 'Mégse'
    });
})(jQuery);
