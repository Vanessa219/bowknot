(function ($) {
    $.mobiscroll.i18n.es = $.extend($.mobiscroll.i18n.es, {
        setText: 'Aceptar',
        cancelText: 'Cancelar'
    });
})(jQuery);
