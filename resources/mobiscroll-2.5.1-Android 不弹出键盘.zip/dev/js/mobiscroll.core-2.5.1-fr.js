(function ($) {
    $.mobiscroll.i18n.fr = $.extend($.mobiscroll.i18n.fr, {
        setText: 'Terminé',
        cancelText: 'Annuler'
    });
})(jQuery);
