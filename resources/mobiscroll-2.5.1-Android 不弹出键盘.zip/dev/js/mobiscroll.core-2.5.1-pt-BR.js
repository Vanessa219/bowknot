/*
 * Translation by: Ivan Gomes <contato@ivangomes.com.br>
 *
 */
(function ($) {
    $.mobiscroll.i18n['pt-BR'] = $.extend($.mobiscroll.i18n['pt-BR'], {
        setText: 'Selecionar',
        cancelText: 'Cancelar'
    });
})(jQuery);
