(function ($) {
    $.mobiscroll.i18n.no = $.extend($.mobiscroll.i18n.no, {
        setText: 'OK',
        cancelText: 'Avbryt'
    });
})(jQuery);
